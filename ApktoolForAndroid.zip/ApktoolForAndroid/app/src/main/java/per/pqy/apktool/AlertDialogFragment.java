package per.pqy.apktool;

import android.support.v4.app.DialogFragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.widget.Toast;
import android.app.Dialog;
import android.support.v7.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.CheckBox;
import android.content.DialogInterface;
import android.widget.EditText;

public class AlertDialogFragment extends DialogFragment
{
	private Context context;
	private SharedPreferences sharedPreferences;
	private String shell, warning, decompile, longpress;
	private static String clean, strName;

	public static AlertDialogFragment newInstance(String key, String value, String name)
	{
		final AlertDialogFragment alertDialogFragment = new AlertDialogFragment();
		final Bundle argumemtsBundle = new Bundle();
		argumemtsBundle.putString(key, value);
		alertDialogFragment.setArguments(argumemtsBundle);
		strName = name;
		return alertDialogFragment;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState)
	{
		context = getContext();
		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
		shell = sharedPreferences.getBoolean("root", false) ? "su" : "sh";
		warning = getArguments().containsKey("warning") ? getArguments().getString("warning") : "not_value";
		decompile = getArguments().containsKey("decompile") ? getArguments().getString("decompile") : "not_value";
		longpress = getArguments().containsKey("longpress") ? getArguments().getString("longpress") : "not_value";
		//info = getArguments().getString("info", "not_value");

		AlertDialog.Builder builder = new AlertDialog.Builder(context);

		switch (warning)
		{
			case "not_value":
				break;
			case "clean":
				clean = getString(R.string.frames_removed);
				boolean checked = sharedPreferences.getBoolean("dont_show", false);
				if (checked != false)
				{
					dismiss();
					onCleanFramework();
					break;
				}
				View view = LayoutInflater.from(context).inflate(R.layout.dialog_clean_famework_view, null);
				final CheckBox checkBox = (CheckBox) view.findViewById(R.id.dont_show_checkbox);
				checkBox.setChecked(checked);
				builder.setView(view);
				builder.setTitle(R.string.framework_clean_title);
				builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							sharedPreferences.edit().putBoolean("dont_show", checkBox.isChecked()).commit();
							onCleanFramework();
						}
					});
				builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							sharedPreferences.edit().putBoolean("dont_show", checkBox.isChecked()).commit();
							// TODO: Implement this method
						}
					});
				break;
			case "microsd_not_exists":
				builder.setTitle(R.string.warning);
				builder.setMessage(R.string.message_warning);
				builder.setPositiveButton(R.string.close, null);
				break;
			case "no_permission":
				builder.setTitle(R.string.no_permission);
				builder.setMessage(R.string.message_permission);
				builder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							((MainFragment)getTargetFragment()).onPermissionClick();
							// TODO: Implement this method
						}
					});
				builder.setNegativeButton(android.R.string.cancel, null);
				break;
			case "dir_exists":
				builder.setTitle(R.string.warning);
				builder.setMessage(R.string.dir_exists);
				builder.setPositiveButton(R.string.close, null);
				break;
			case "dir_not_exists":
				builder.setTitle(R.string.warning);
				builder.setMessage(R.string.dir_not_exists);
				builder.setPositiveButton(R.string.close, null);
				break;
			case "apk_not_exists":
				builder.setTitle(R.string.warning);
				builder.setMessage(R.string.apk_not_exists);
				builder.setPositiveButton(R.string.close, null);
				break;
			case "install_tools":
				String str = String.format(getString(R.string.message_install_tools), strName.substring(0, strName.lastIndexOf(".")));
				builder.setTitle(R.string.warning);
				builder.setMessage(str);
				builder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							((MainFragment)getTargetFragment()).onInstall();
							// TODO: Implement this method
						}
					});
				builder.setNegativeButton(android.R.string.cancel, null);
				break;
		}
		switch (decompile)
		{
			case "not_value":
				break;
			case "apk":
				builder.setTitle(R.string.dialog_selecting);
				builder.setItems(R.array.dialog_item_apk, new DialogInterface.OnClickListener(){
						String type;
						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							switch (p2)
							{
								case 0:
									type = "decompile_all";
									break;
								case 1:
									type = "decompile_dex";
									break;
								case 2:
									type = "decompile_res";
									break;
								case 3:
									type = "del_dex";
									break;
								case 4:
									type = "del_meta_inf";
									break;
								case 5:
									type = "extract_meta_inf";
									break;
								case 6:
									type = "add_meta_inf";
									break;
								case 7:
									type = "sign_apk";
									break;
								case 8:
									type = "zipalign";
									break;
								case 9:
									type = "install";
									break;
								case 10:
									type = "import_framework";
									break;
								case 11:
									type = "create_odex";
									break;
							}
							((MainFragment)getTargetFragment()).onApkClick(type);
							// TODO: Implement this method
						}
					});
				break;
			case "dex":
				builder.setTitle(R.string.dialog_selecting);
				builder.setItems(R.array.dialog_item_file_dex, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							switch (p2)
							{
								case 0:
									((MainFragment)getTargetFragment()).onDecompileClick("decompile_dex");
									break;
								case 1:
									((MainFragment)getTargetFragment()).onOtherClick("add_to_apk");
									break;
							}
							// TODO: Implement this method
						}
					});
				break;
			case "odex":
				builder.setTitle(R.string.dialog_selecting);
				builder.setItems(R.array.dialog_item_file_odex, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							switch (p2)
							{
								case 0:
									((MainFragment)getTargetFragment()).onDecompileClick("decompile_odex");
									break;
								case 1:
									((MainFragment)getTargetFragment()).onDeodexClick("oat2dex");
									break;
								case 2:
									((MainFragment)getTargetFragment()).onDeodexClick("oatdump");
									break;
							}
							// TODO: Implement this method
						}
					});
				break;
		}
		switch (longpress)
		{
			case "not_value":
				break;
			case "file":
			case "folder":
				builder.setTitle(R.string.dialog_selecting);
				builder.setItems(longpress.equals("file") ? R.array.dialog_item_file : R.array.dialog_item_folder, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							switch (p2)
							{
								case 0:
									onRename();
									break;
								case 1:
									onDelete();
									break;
								case 2:
									((MainFragment)getTargetFragment()).onCardPathClick();
									break;
							}
							// TODO: Implement this method
						}
					});
				break;
			case "src":
			case "dex":
			case "odex":
				builder.setTitle(R.string.dialog_selecting);
				builder.setItems(R.array.dialog_item_compile, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							switch (p2)
							{
								case 0:
									((MainFragment)getTargetFragment()).onCompileClick("compile_" + longpress);
									break;
								case 1:
									onRename();
									break;
								case 2:
									onDelete();
									break;
							}
							// TODO: Implement this method
						}
					});
				break;
		}
		// TODO: Implement this method
		return builder.create();
	}

	void onRename()
	{
		View view = LayoutInflater.from(context).inflate(R.layout.dialog_edittext_view, null);
		int index = strName.lastIndexOf(".");
		final EditText editText = (EditText) view.findViewById(R.id.edit_text);
		editText.setText(strName);
		editText.setSelection(index > 0 ? index : strName.length());
		new AlertDialog.Builder(context).
			setTitle(R.string.rename).
			setView(view).
			setPositiveButton(R.string.rename, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					((MainFragment)getTargetFragment()).onRenameClick(editText.getText().toString());
					// TODO: Implement this method
				}
			}).
			setNegativeButton(android.R.string.cancel, null).
			show();

	}

	void onDelete()
	{
		new AlertDialog.Builder(context).
			setTitle(R.string.delete).
			setMessage(getString(R.string.message_delete) + " \"" + strName + "\"").
			setPositiveButton(R.string.delete, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					((MainFragment)getTargetFragment()).onDeleteClick();
					// TODO: Implement this method
				}
			}).
			setNegativeButton(android.R.string.cancel, null).
			show();
	}

	private Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg)
		{
			// TODO: Implement this method
			super.handleMessage(msg);
			Bundle bundle = msg.getData();
			String err_out = bundle.getString("error") + bundle.getString("output");
			Toast.makeText(context, err_out.isEmpty() ? clean : err_out, Toast.LENGTH_SHORT).show();
		}

	};

	private void onCleanFramework()
	{
		String command = "rm -r '/data/data/per.pqy.apktool/'*.apk";
		RunExec.runWork(shell, command, handler, "", "");
	}
}
