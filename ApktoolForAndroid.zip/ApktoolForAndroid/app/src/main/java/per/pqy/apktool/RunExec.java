package per.pqy.apktool;

import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class RunExec
{
	public static void runWork(final String shell, final String command, final Handler handler, final String title, final String file)
	{
		Runnable runnable = new Runnable(){

			@Override
			public void run()
			{

				Process process = null;
				DataOutputStream dataOutputStream = null;
				InputStreamReader inputStreamReader = null;
				InputStreamReader errorStreamReader = null;
				Bundle bundle = new Bundle();
				Message message = new Message().obtain();
				bundle.putLong("time", System.currentTimeMillis());

				try
				{
					process = Runtime.getRuntime().exec(shell);
					dataOutputStream = new DataOutputStream(process.getOutputStream());
					dataOutputStream.writeBytes(command + "\n");
					dataOutputStream.writeBytes("exit\n");
					dataOutputStream.flush();

					inputStreamReader = new InputStreamReader(process.getInputStream());
					errorStreamReader = new InputStreamReader(process.getErrorStream());

					BufferedReader bufferedReaderError = new BufferedReader(errorStreamReader);
					String err; 
					String error = "";
					while ((err = bufferedReaderError.readLine()) != null)
					{
						error += err + "\n";
					}
					bufferedReaderError.close();
					//errorStreamReader.close();

					BufferedReader bufferedReaderOutput = new BufferedReader(inputStreamReader);
					String in;
					String output ="";
					while ((in = bufferedReaderOutput.readLine()) != null)
					{
						output += in + "\n";
					}
					bufferedReaderOutput.close();
					//inputStreamReader.close();

					process.waitFor();

					bundle.putString("title", title);
					bundle.putString("file", file);
					bundle.putString("error", output.equals("") ? error.trim() : error);
					bundle.putString("output", output.trim());

					message.setData(bundle);
					handler.sendMessage(message);
				}
				catch (Exception e)
				{}
				finally
				{
					try
					{
						if (inputStreamReader != null) inputStreamReader.close();
					}
					catch (IOException e)
					{}
					try
					{
						if (errorStreamReader != null) errorStreamReader.close();
					}
					catch (IOException e)
					{}
					try
					{
						if (dataOutputStream != null) dataOutputStream.close();
					}
					catch (IOException e)
					{}
					process.destroy();
				}
				// TODO: Implement this method
			}
		};
		new Thread(runnable).start();
	}

	public static void Cmd(String shell, String command)
	{
		Process process = null;
		DataOutputStream dataOutputStream = null;

		try
		{
			process = Runtime.getRuntime().exec(shell);
			dataOutputStream = new DataOutputStream(process.getOutputStream());
			dataOutputStream.writeBytes(command + "\n");
			dataOutputStream.writeBytes("exit\n");
			dataOutputStream.flush();
			process.waitFor();
		}
		catch (Exception e)
		{}
		finally
		{
			try
			{
				if (dataOutputStream != null) dataOutputStream.close();
			}
			catch (IOException e)
			{}
			process.destroy();
		}
		return;
	}
}
