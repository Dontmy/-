package per.pqy.apktool;

import android.support.v7.widget.RecyclerView;
import android.content.Context;
import java.io.File;
import com.squareup.picasso.Picasso;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import java.util.Date;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder>
{
	public static interface ClickListener
	{
		void onItemClick(int position);
		void onItemLongClick(int position);
	}

	private static ClickListener listener;
	private static Context context;
	private static File[] dataset;
	private static Picasso picassoRequestHandler, picasso;
	private static SimpleDateFormat simpleDateFormat;
	private static DecimalFormat decimalFormat;
	private File file;

	public static class ViewHolder extends RecyclerView.ViewHolder
	{
		private TextView fileName;
		private TextView fileDesc;
		private TextView fileSize;
		private ImageView fileIcon;

		public ViewHolder(View view)
		{
			super(view);

			fileName = (TextView) view.findViewById(R.id.file_name);
			fileDesc = (TextView) view.findViewById(R.id.file_desc);
			fileSize = (TextView) view.findViewById(R.id.file_size);
			fileIcon = (ImageView) view.findViewById(R.id.file_icon);

			view.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1)
					{
						listener.onItemClick(getPosition());
						// TODO: Implement this method
					}
				});
			view.setOnLongClickListener(new View.OnLongClickListener(){

					@Override
					public boolean onLongClick(View p1)
					{
						listener.onItemLongClick(getPosition());
						// TODO: Implement this method
						return true;
					}
				});
		}
	}

	public MainAdapter(File[] d, ClickListener l, Context c)
	{
		dataset = d;
		this.listener = l;
		context = c;
		picassoRequestHandler = new Picasso.Builder(c).addRequestHandler(new AppIconRequestHandler(c)).build();
		picasso = Picasso.with(c);
	}

	@Override
	public MainAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
	{
	    simpleDateFormat = new SimpleDateFormat("dd MMM yyyy  HH:mm:ss");
		decimalFormat = new DecimalFormat("#0.00");
		View v = LayoutInflater.from(p1.getContext()).inflate(R.layout.recycler_main_item, p1, false);

		// TODO: Implement this method
		return new ViewHolder(v);
	}

	@Override
	public void onBindViewHolder(ViewHolder p1, int p2)
	{

		file = dataset[p2];
		String name = file.getName().toLowerCase();
		p1.fileName.setText(file.getName());
		p1.fileDesc.setText(simpleDateFormat.format(new Date(file.lastModified())));
		p1.fileSize.setText(file.isFile() ? sizeFile(file) : "");
		if (file.isDirectory())
			picasso.load(!file.canRead() ? R.drawable.ic_folder_lock_144dp : R.drawable.ic_folder_144dp).placeholder(R.drawable.ic_file_default_144dp).into(p1.fileIcon);
		else if (name.endsWith(".apk"))
			picassoRequestHandler.load(AppIconRequestHandler.SCHEME_APP_ICON + ":" + file).placeholder(R.drawable.ic_file_default_144dp).error(R.drawable.ic_file_android_144dp).into(p1.fileIcon);
		//p1.fileIcon.setImageDrawable(iconApk(file.getPath()));
		else if (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".gif"))
			picasso.load(file).placeholder(R.drawable.ic_file_default_144dp).error(R.drawable.ic_image_144dp).fit().centerInside().into(p1.fileIcon);
		else
			picasso.load(iconFile(name)).placeholder(R.drawable.ic_file_default_144dp).into(p1.fileIcon);
		// TODO: Implement this method
	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return dataset.length;
	}

	private static int iconFile(String name)
	{
		if (name.endsWith(".yml")) return R.drawable.ic_xml_144dp;
		else if (name.endsWith(".smali")) return R.drawable.ic_file_smali_144dp;
		else if (name.endsWith(".so")) return R.drawable.ic_file_so_144dp;
		else if (name.endsWith(".xml") || name.endsWith(".html")) return R.drawable.ic_file_xml_144dp;
		else if (name.endsWith(".odex")) return R.drawable.ic_file_odex_144dp;
		else if (name.endsWith(".dex")) return R.drawable.ic_file_dex_144dp;
		else if (name.endsWith("jar") || name.endsWith(".zip") || name.endsWith(".tar") || name.endsWith(".rar") || name.endsWith(".tools")) return R.drawable.ic_file_zip_144dp;
		else return R.drawable.ic_file_144dp;
	}

	/*private static Drawable iconApk(String path)
	 {
	 PackageManager pm = context.getPackageManager();
	 PackageInfo info = pm.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES);
	 if (info != null)
	 {
	 info.applicationInfo.sourceDir = path;
	 info.applicationInfo.publicSourceDir = path;
	 Drawable ic = info.applicationInfo.loadIcon(pm);
	 if(ic != null)
	 return ic;
	 //imageView.setImageDrawable(d);
	 else 
	 return context.getResources().getDrawable(R.drawable.ic_file_android_144dp);
	 }
	 else
	 {
	 return context.getResources().getDrawable(R.drawable.ic_file_android_144dp);
	 //imageView.setImageResource(R.drawable.ic_file_android_144dp);
	 }
	 }*/

	public static String sizeFile(File f)
	{
		long size = f.length();
		if (size >= 1073741824)
		{
			return decimalFormat.format((double) size / 1073741824.0) + "G";
		}
		else if (size >= 1048576)
		{
			return decimalFormat.format((double) size / 1048576.0) + "M";
		}
		else if (size >= 1024)
		{
			return decimalFormat.format((double) size / 1024) + "K";
		}
		else
		{
			return Long.toString(size) + "B";
		}
	}

}
