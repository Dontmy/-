package per.pqy.apktool;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.TextView;
import android.widget.ImageView;
import java.io.File;

public class InfoAdapter extends RecyclerView.Adapter<InfoAdapter.ViewHolder>
{
	private File[] dataset;
	private File file;

	public static class ViewHolder extends RecyclerView.ViewHolder
	{
		private TextView fileName;
		private TextView fileSize;
		private ImageView fileIcon;

		public ViewHolder(View view)
		{
			super(view);
			fileName = (TextView) view.findViewById(R.id.info_name);
			fileSize = (TextView) view.findViewById(R.id.info_size);
			fileIcon = (ImageView) view.findViewById(R.id.info_icon);
		}
	}

	public InfoAdapter(File[] f)
	{
		dataset = f;
	}

	@Override
	public InfoAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
	{
		View v = LayoutInflater.from(p1.getContext()).inflate(R.layout.recycler_info_item, p1, false);
		// TODO: Implement this method
		return new ViewHolder(v);
	}

	@Override
	public void onBindViewHolder(ViewHolder p1, int p2)
	{
		file = dataset[p2];
		p1.fileName.setText(file.getName());
		p1.fileSize.setText(MainAdapter.sizeFile(file));
		p1.fileIcon.setImageResource(file.getName().startsWith("aapt") ? R.drawable.ic_matrix_24dp : R.drawable.ic_zip_box_24dp);
		//p1.fileIcon.setBackgroundResource(R.drawable.file_background);
		// TODO: Implement this method
	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return dataset.length;
	}

}
