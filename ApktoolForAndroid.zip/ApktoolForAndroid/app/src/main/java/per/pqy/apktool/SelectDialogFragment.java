package per.pqy.apktool;

import android.support.v7.app.AppCompatDialogFragment;
import java.io.File;
import android.widget.TextView;
import android.support.v7.widget.RecyclerView;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.widget.Toast;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.support.v7.widget.LinearLayoutManager;
import android.os.Environment;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.Comparator;
import android.support.v7.preference.PreferenceManager;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;

public class SelectDialogFragment extends AppCompatDialogFragment implements SelectAdapter.ClickListener
{
	private String resultMessage, fileName, shell, err;
	private File file;
	private File[] files;
	private TextView folderTextView;
	private RecyclerView recyclerView;
	private String path = "/data/data/per.pqy.apktool/apktool";

	@Override
	public void onItemClick(int positoin)
	{
		file = files[positoin];
		fileName = file.getName();
		if (!file.isFile())
		{
			if (file.canRead())
			{
				listFilesAdapter(file);
			}
			else
			{
				Toast.makeText(getContext(), R.string.no_permission, Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			dismiss();
			copyFile(fileName);
		}
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		getDialog().setTitle(R.string.file_update_dialog_title);
		View view = inflater.inflate(R.layout.recycler_select_view, container, false);
		folderTextView = (TextView) view.findViewById(R.id.adapter_folder_path);
		recyclerView = (RecyclerView) view.findViewById(R.id.select_recycler_view);
		recyclerView.setHasFixedSize(true);
		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
		listFilesAdapter(Environment.getExternalStorageDirectory());
		resultMessage = getString(R.string.file_update_result);
		// TODO: Implement this method
		return view;
	}

	private void listFilesAdapter(final File f)
	{
		files = f.listFiles(new FileFilter(){

				@Override
				public boolean accept(File p1)
				{
					String name = p1.getName();
					// TODO: Implement this method
					return p1.isDirectory() || name.matches("(apktool|smali|baksmali)(_|-)[0-9.a-z]*.jar") || name.startsWith("aapt");
				}
			});
		Arrays.sort(files, new Comparator<File>(){

				@Override
				public int compare(File p1, File p2)
				{
					if (p1.isDirectory())
					{
						if (p2.isDirectory())
						{
							return String.valueOf(p1.getName().toLowerCase()).compareTo(p2.getName().toLowerCase());
						}
						else
						{
							return -1;
						}
					}
					else
					{
						if (p2.isDirectory())
						{
							return 1;
						}
						else
						{
							return String.valueOf(p1.getName().toLowerCase()).compareTo(p2.getName().toLowerCase());
						}
					}
					/*if (p1.isDirectory() && p2.isFile()) return -1;
					 else if (p1.isFile() && p2.isDirectory()) return 1;
					 else return p1.getName().toLowerCase().compareTo(p2.getName().toLowerCase());*/
				}
			});

		recyclerView.setAdapter(new SelectAdapter(files, this));

		folderTextView.setText((f.getPath().equals("/") ? "" : "← ") + f.getPath());
		folderTextView.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if (!f.getPath().equals("/"))
					{
						if (f.getParentFile().canRead())
						{
							listFilesAdapter(f.getParentFile());
						}
						else if (f.getParentFile().getParentFile().canRead())
						{
							listFilesAdapter(f.getParentFile().getParentFile());
						}
						else
						{
							Toast.makeText(getContext(), R.string.no_permission, Toast.LENGTH_SHORT).show();
						}
					}
				}
			});
	}

	private void copyFile(String str)
	{
		shell = PreferenceManager.getDefaultSharedPreferences(getContext()).getBoolean("root", false) ? "su" : "sh";
		err = "";

		readWriteFile(str);
		if (str.startsWith("aapt")) path += "/openjdk/bin";

		String command = "/data/data/per.pqy.apktool/busybox cp " + file.getAbsolutePath() + "  " + path + "/" + str + " && /data/data/per.pqy.apktool/busybox chmod -R 777 /data/data/per.pqy.apktool/apktool";

		if (err.isEmpty())
			RunExec.runWork(shell, command, handler, "", "");
		else
			Toast.makeText(getContext(), err, Toast.LENGTH_SHORT).show();
	}

	private void readWriteFile(String str)
	{
		String filePath, prefix;
		if (str.startsWith("apktool"))
		{
			prefix = "apktool";
			filePath = path + "/apktool2.sh";
		}
		else if (str.startsWith("smali"))
		{
			prefix = "smali";
			filePath = path + "/smali.sh";
		}
		else if (str.startsWith("baksmali"))
		{
			prefix = "baksmali";
			filePath = path + "/baksmali.sh";
		}
		else
		{
			return;
		}

		try
		{
			String line;
			String out = "";
			FileReader fr = new FileReader(filePath);
			BufferedReader br = new BufferedReader(fr);
			while ((line = br.readLine()) != null)
			{
				out += line.contains(".jar") ? line.replaceFirst("(apktool|smali|baksmali)(_|-)[0-9.a-z]*.jar", str) + "\n" : line + "\n";
			}
			br.close();
			fr.close();

			FileWriter fw = new FileWriter(filePath);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(out.trim());
			bw.close();
			fw.close();
		}
		catch (Exception e)
		{
			err = e.toString();
		}
		if (err.isEmpty())
		{
			String delCommand = "rm -r '" + path + "/'" + prefix + "[_-]*.jar";
			RunExec.Cmd(shell, delCommand);
		}
	}

	private Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg)
		{
			super.handleMessage(msg);
			Bundle bundle = msg.getData();
			String err_out = bundle.getString("error") + bundle.getString("output");

			Toast.makeText(getTargetFragment().getContext(), err_out.isEmpty() ? resultMessage + " " + fileName : err_out, Toast.LENGTH_SHORT).show();
			((SettingsCompatFragment)getTargetFragment()).onListPreference(fileName.startsWith("aapt") ? "aapt_version" : "apktool_version");
		}

	};
}
