package per.pqy.apktool;

import com.squareup.picasso.RequestHandler;
import android.content.Context;
import android.content.pm.PackageManager;
import com.squareup.picasso.Request;
import java.io.IOException;
import android.graphics.Bitmap;
import android.content.pm.PackageInfo;
import android.graphics.drawable.BitmapDrawable;
import com.squareup.picasso.Picasso;

public class AppIconRequestHandler extends RequestHandler
{

	public static final String SCHEME_APP_ICON = "app-icon";
	private static Context context;
	private static PackageManager packageManager;

	public AppIconRequestHandler(Context c)
	{
		context = c;
		packageManager = context.getPackageManager();
	}

	@Override
	public boolean canHandleRequest(Request p1)
	{
		String scheme = p1.uri.getScheme();
		// TODO: Implement this method
		return (SCHEME_APP_ICON.equals(scheme));
	}

	@Override
	public RequestHandler.Result load(Request p1, int p2) throws IOException
	{
		Bitmap appIcon;
		//packageManager = context.getPackageManager();
		String path = p1.uri.getPath();
		PackageInfo info = packageManager.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES);
		if (info != null)
		{
			info.applicationInfo.sourceDir = path;
			info.applicationInfo.publicSourceDir = path;
			appIcon = ((BitmapDrawable) info.applicationInfo.loadIcon(packageManager)).getBitmap();
		}
		else
		{
			appIcon = ((BitmapDrawable) context.getResources().getDrawable(R.drawable.ic_file_android_144dp)).getBitmap();
		}
		RequestHandler.Result result = new RequestHandler.Result(appIcon, Picasso.LoadedFrom.DISK);
		return result;
		// TODO: Implement this method
	}

}
