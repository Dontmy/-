package per.pqy.apktool;

import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Vibrator;
import android.widget.TextView;
import android.content.Context;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import java.io.File;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.content.DialogInterface;
import android.support.v7.preference.PreferenceManager;
import android.support.v7.widget.LinearLayoutManager;
import java.util.Arrays;
import java.util.Comparator;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.content.Intent;
import android.net.Uri;
import java.util.Set;
import java.util.HashSet;
import android.widget.Toast;
import android.support.design.widget.Snackbar;
import android.content.pm.*;

public class MainFragment extends Fragment implements MainAdapter.ClickListener
{
	AlertDialog dialogProgressBar, dialogResult;
	private SharedPreferences sharedPreferences;
	Vibrator vibration;
	private static long[] pattern = new long[]{0, 200, 100, 200};
	private TextView costTime, outputText;
	private Context context;
	private static final String STORAGE_PATH = Environment.getExternalStorageDirectory().getPath();
	private String currentPath, shell, command, diff, apktoolVersion, aaptVersion;
	private RecyclerView.LayoutManager layoutManager;
	private int positionIndex;
	public File filePath;
	private File file;
	private File[] files;
	private RecyclerView.Adapter recyclerAdapter;
	private RecyclerView recyclerView;
	private static final String API_LEVEL = Build.VERSION.SDK;
	//private static long[] pattern = new long[]{0, 200, 100, 200};

	private static String workTime(long t, String h, String m, String s)
	{
		long time = (System.currentTimeMillis() - t) / 1000;
		if (time > 3600)
		{
			return "" + time / 3600 + h + " " + (time % 3600) / 60 + m + " " + time % 60 + s;
		}
		else if (time > 60)
		{
			return "" + (time % 3600) / 60 + m + " " + time % 60 + s;
		}
		else
		{
			return "" + time + s;
		}
	}

	private void resultWork(Bundle bundle)
	{
		String time = workTime(bundle.getLong("time"), getString(R.string.hour), getString(R.string.minute), getString(R.string.second));
		String outCostTime = String.format(getString(R.string.dialog_process_result), bundle.getString("file"), time);
		costTime.setText(outCostTime);
		final String err_out = bundle.getString("error") + bundle.getString("output");
		outputText.setText(err_out);
		dialogResult.setTitle(bundle.getString("title"));
		dialogResult.setButton(DialogInterface.BUTTON_POSITIVE, getString(android.R.string.copy), new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					if (Build.VERSION.SDK_INT < 11)
					{
						android.text.ClipboardManager clipboardManager = (android.text.ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
						clipboardManager.setText(err_out);
					}
					else
					{
						android.content.ClipboardManager clipboardManager = (android.content.ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
						android.content.ClipData clipData = android.content.ClipData.newPlainText("apktool log", err_out);
						clipboardManager.setPrimaryClip(clipData);
					}
					// TODO: Implement this method
				}
			});
	}

	Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg)
		{
			dialogProgressBar.cancel();
			onRefresh();
			// TODO: Implement this method
			super.handleMessage(msg);
			resultWork(msg.getData());
			dialogResult.show();

			if (sharedPreferences.getBoolean("vibration", false))
			{
				vibration.vibrate(pattern, -1);
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		context = getActivity();
		//STORAGE_PATH = Environment.getExternalStorageDirectory().getPath();
		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
		currentPath = sharedPreferences.getString("current_path", STORAGE_PATH);
		if (!currentPath.equals(STORAGE_PATH) && !new File(currentPath).canRead()) currentPath = STORAGE_PATH;
		vibration = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);

		dialogProgressBar = new AlertDialog.Builder(context).setCancelable(false).setPositiveButton(R.string.to_hide_process, null).create();
		dialogResult = new AlertDialog.Builder(context).setNegativeButton(android.R.string.cancel, null).create();
	}

	public void getDataPath(String path)
	{
		positionIndex = ((LinearLayoutManager)layoutManager).findFirstVisibleItemPosition();
		filePath = new File(path);
		files = filePath.listFiles();
		Arrays.sort(files, new Comparator<File>(){

				@Override
				public int compare(File p1, File p2)
				{
					if (p1.isDirectory())
					{
						if (p2.isDirectory())
						{
							return String.valueOf(p1.getName().toLowerCase()).compareTo(p2.getName().toLowerCase());
						}
						else
						{
							return -1;
						}
					}
					else
					{
						if (p2.isDirectory())
						{
							return 1;
						}
						else
						{
							return String.valueOf(p1.getName().toLowerCase()).compareTo(p2.getName().toLowerCase());
						}
					}
				}

			});
		recyclerAdapter = new MainAdapter(files, this , context);
		recyclerView.setAdapter(recyclerAdapter);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		View rootView = inflater.inflate(R.layout.recycler_main_view, null);
		View viewDialogProgress = inflater.inflate(R.layout.dialog_progressbar_view, null);
		dialogProgressBar.setView(viewDialogProgress);

		View viewDialogResult = inflater.inflate(R.layout.dialog_scrollview_view, null);
		costTime = (TextView) viewDialogResult.findViewById(R.id.cost_time);
		outputText = (TextView) viewDialogResult.findViewById(R.id.output_text);
		//if(Build.VERSION.SDK_INT >= 11) outputText.setTextIsSelectable(true);
		dialogResult.setView(viewDialogResult);

		recyclerView = (RecyclerView) rootView.findViewById(R.id.main_recycler_view);
		recyclerView.setHasFixedSize(true);
		layoutManager = new LinearLayoutManager(context);
		recyclerView.setLayoutManager(layoutManager);
		getDataPath(currentPath);

		//recyclerView.addItemDecoration(new DividerItemDecoration(context, DividerItemDecoration.VERTICAL));
		//recyclerView.setItemAnimator(new DefaultItemAnimator());
		// TODO: Implement this method
		return rootView;
	} 

	private void startWork(String startTitle, String command, String finishTitle)
	{
		shell = sharedPreferences.getBoolean("root", false) ? "su" : "sh";
		dialogProgressBar.setTitle(startTitle);
		dialogProgressBar.show();
		RunExec.runWork(shell, command, handler, finishTitle, file.getName());
	}

	@Override
	public void onItemClick(int position)
	{
		file = files[position];
		String name = file.getName();
		if (file.isDirectory())
		{
			if (!file.canRead()) showDialog("warning", "no_permission", "");
			else getDataPath(file.getPath());
		}
		else
		{
			if (name.endsWith(".apk")) showDialog("decompile", "apk", "");
			else if (name.endsWith(".dex")) showDialog("decompile", "dex", "");
			else if (name.endsWith(".odex")) showDialog("decompile", "odex", "");
			else if (name.endsWith(".tools")) showDialog("warning", "install_tools", name);
			else startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.fromFile(file), "*/*"));
		}
		// TODO: Implement this method
	}

	@Override
	public void onItemLongClick(int position)
	{
		file = files[position];
		String name = file.getName();
		String type;
		if (name.endsWith("_src")) type = "src";
		else if (name.endsWith("_dex")) type = "dex";
		else if (name.endsWith("_odex")) type = "odex";
		else if (file.isDirectory()) type = "folder";
		else type = "file";
		// TODO: Implement this method
		showDialog("longpress", type, name);
	}

	protected void onInstall()
	{
		command = "";
		if (new File("/data/data/per.pqy.apktool/apktool").exists())
			command = "rm -r /data/data/per.pqy.apktool/apktool && ";
		command += "/data/data/per.pqy.apktool/busybox tar xpf " + file.getPath() + " --directory=/data/data/per.pqy.apktool/" + " && " + " /data/data/per.pqy.apktool/busybox chmod -R 777 /data/data/per.pqy.apktool/apktool";
		startWork(getString(R.string.install), command, getString(R.string.import_finish));
	}

	protected void onApkClick(String type)
	{
		String decompileFlags = "";
		if (sharedPreferences.getBoolean("pro", false) != false)
		{
			if (Build.VERSION.SDK_INT < 11)
			{
				if (sharedPreferences.getBoolean("no-debug-info", false)) decompileFlags += "-b ";
				if (sharedPreferences.getBoolean("keep-broken-res", false)) decompileFlags += "--keep-broken-res ";
				if (sharedPreferences.getBoolean("match-original", false)) decompileFlags += "-m ";
			}
			else
			{
				Set<String> dFlags = sharedPreferences.getStringSet("decompile_flags", new HashSet<String>());
				for (String df : dFlags)
				{
					switch (df)
					{
						case "b":
							decompileFlags += "-b ";
							break;
						case "k":
							decompileFlags += "--keep-broken-res ";
							break;
						case "m":
							decompileFlags += "-m ";
							break;
					}
				}
			}
		}

		String uri = file.getPath();
		if (sharedPreferences.getString("apktool_version", "2").equals("1"))
		{
			diff = " ";
			apktoolVersion = "/data/data/per.pqy.apktool/apktool/apktool.sh";
		}
		else
		{
			diff = " -o ";
			apktoolVersion = "/data/data/per.pqy.apktool/apktool/apktool2.sh";
		}

		switch (type)
		{
			case "decompile_all":
				command = apktoolVersion + " d -f " + decompileFlags + "'" + uri + "'" + diff + "'" + uri.substring(0, uri.length() - 4) + "_src'";
				//Toast.makeText(context, command, Toast.LENGTH_SHORT).show();
				startWork(getString(R.string.decompiling), command, getString(R.string.decompile_finish));
				break;
			case "decompile_dex":
				command = apktoolVersion + " d -f -r " + decompileFlags + "'" + uri + "'" + diff + "'" + uri.substring(0, uri.length() - 4) + "_src'";
				startWork(getString(R.string.decompiling) + " dex", command, getString(R.string.decompile_finish));
				break;
			case "decompile_res":
				command = apktoolVersion + " d -f -s " + decompileFlags + "'" + uri + "'" + diff + "'" + uri.substring(0, uri.length() - 4) + "_src'";
				startWork(getString(R.string.decompiling) + " res", command, getString(R.string.decompile_finish));
				break;
			case "del_dex":
				command = "/data/data/per.pqy.apktool/apktool/7z.sh '" + file.getParent() + "' d -tzip '" + uri + "' classes.dex";
				startWork(getString(R.string.deleting) + " dex", command, getString(R.string.delete_finish));
				break;
			case "del_meta_inf":
				command = "/data/data/per.pqy.apktool/apktool/7z.sh '" + file.getParent() + "' d -tzip " + "'" + uri + "'" + " META-INF";
				startWork(getString(R.string.deleting) + " META-INF", command, getString(R.string.delete_finish));
				break;
			case "extract_meta_inf":
				if (!new File(file.getParent() + "/META-INF").exists())
				{
					command = "/data/data/per.pqy.apktool/apktool/7z.sh '"  + file.getParent() + "' x -tzip '" + uri + "' META-INF";
					startWork(getString(R.string.extracting) + " META-INF", command, getString(R.string.operation_finish));
				}
				else
				{
					showDialog("warning", "dir_exists", "");
				}
				break;
			case "add_meta_inf":
				String metaPath = file.getParent();
				if (new File(metaPath + "/META-INF").exists())
				{
					command = "/data/data/per.pqy.apktool/apktool/7z.sh '" + metaPath + "' a -tzip '" + uri + "' '" + metaPath + "/META-INF'";
					startWork(getString(R.string.adding) + " META-INF", command, getString(R.string.add_finish));
				}
				else
				{
					showDialog("warning", "dir_not_exists", "");
				}
				break;
			case "sign_apk":
				command = "/data/data/per.pqy.apktool/apktool/signapk.sh "
					+ "'" + uri + "' '" + uri.substring(0, uri.length() - 4) + "_sign.apk'";
				startWork(getString(R.string.signing), command, getString(R.string.sign_finish));
				break;
			case "zipalign":
				command = "/data/data/per.pqy.apktool/apktool/openjdk/bin/zipalign -f 4 " + "'" + uri + "' '" + uri.substring(0, uri.length() - 4) + "_zipalign.apk'";
				startWork(getString(R.string.zipaligning), command, getString(R.string.zipalign_finish));
				break;
			case "install":
				startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive"));
				break;
			case "import_framework":
				command = apktoolVersion + " if '" +  uri + "'";
				startWork(getString(R.string.importing_framework), command, getString(R.string.import_finish));
				break;
			case "create_odex":
				command = "/data/data/per.pqy.apktool/apktool/openjdk/bin/dexopt-wrapper " + "'" + uri + "' '" + uri.substring(0, uri.length() - 3) + "odex'";
				startWork(getString(R.string.creating) + " odex", command, getString(R.string.create_finish));	
				break;
			default:
				Toast.makeText(getActivity(), "Unknown", Toast.LENGTH_SHORT).show();
				break;
		}
	}

	protected void onCompileClick(String type)
	{
		String compileFlags = "";
		if (sharedPreferences.getBoolean("pro", false) != false)
		{
			if (Build.VERSION.SDK_INT < 11)
			{
				if (sharedPreferences.getBoolean("copy-original", false)) compileFlags += "-c ";
				if (sharedPreferences.getBoolean("debug", false)) compileFlags += "-d ";
			}
			else
			{
				Set<String> cFlags = sharedPreferences.getStringSet("compile_flags", new HashSet<String>());
				for (String cf : cFlags)
				{
					switch (cf)
					{
						case "c":
							compileFlags += "-c ";
							break;
						case "d":
							compileFlags += "-d ";
							break;
					}
				}
			}
		}

		String uri = file.getPath();
		aaptVersion = "/data/data/per.pqy.apktool/apktool/openjdk/bin/aapt" + sharedPreferences.getString("aapt_version", "4.4");
		if (sharedPreferences.getString("apktool_version", "2").equals("1"))
		{
			diff = " ";
			apktoolVersion = "/data/data/per.pqy.apktool/apktool/apktool.sh";
		}
		else
		{
			diff = " -o ";
			apktoolVersion = "/data/data/per.pqy.apktool/apktool/apktool2.sh";
		}

		switch (type)
		{
			case "compile_src":
				command = apktoolVersion + " b -f " + compileFlags + " -a " + aaptVersion + " '" + uri + "'" + diff + "'" + uri + ".apk'";
				startWork(getString(R.string.recompiling), command, getString(R.string.recompile_finish));
				break;
			case "compile_dex":
				command = "/data/data/per.pqy.apktool/apktool/smali.sh -a " + API_LEVEL + " '" + uri + "' -o '" + uri.substring(0, uri.length() - 4) + ".dex'";
				startWork(getString(R.string.recompiling) + " dex", command, getString(R.string.recompile_finish));
				break;
			case "compile_odex":
				command = "/data/data/per.pqy.apktool/apktool/smali.sh -a " + API_LEVEL + " '" + uri + "' -o '" + uri.substring(0, uri.length() - 5) + ".dex'";
				startWork(getString(R.string.recompiling) + " odex", command, getString(R.string.recompile_finish));
				break;
		}
	}

	protected void onDecompileClick(String type)
	{
		String uri = file.getPath();
		switch (type)
		{
			case "decompile_dex":
				command = "/data/data/per.pqy.apktool/apktool/baksmali.sh -a " + API_LEVEL + " -x " + uri + " -o " + uri.substring(0, uri.length() - 4) + "_dex";
				startWork(getString(R.string.decompiling) + " dex", command, getString(R.string.decompile_finish));
				break;
			case "decompile_odex":
				command = "/data/data/per.pqy.apktool/apktool/baksmali.sh -a " + API_LEVEL + " -x " + uri + " -o " + uri.substring(0, uri.length() - 5) + "_odex";
				startWork(getString(R.string.decompiling) + " odex", command, getString(R.string.decompile_finish));
				break;
		}
	}

	protected void onDeodexClick(String type)
	{
		String uri = file.getPath();
		switch (type)
		{
			case "oat2dex":
				command = "PATH=/data/data/per.pqy.apktool/apktool/openjdk/bin:$PATH /data/data/per.pqy.apktool/apktool/oat2dex.sh " + uri;
				startWork(getString(R.string.deodexing), command, getString(R.string.deodexing_finish));
				break;
			case "oatdump":
				command = "oatdump --oat-file=" + uri + " --export-dex-to=" + file.getParent();
				startWork(getString(R.string.exporting) + " dex", command, getString(R.string.exporting_finish));
				break;
		}
	}

	protected void onOtherClick(String type)
	{
		String uri = file.getPath();
		switch (type)
		{
			case "add_to_apk":
				String apkFile = uri.substring(0, uri.length() - 3) + "apk";
				if (new File(apkFile).exists())
				{
					RunExec.Cmd(shell, "/data/data/per.pqy.apktool/apktool/openjdk/bin/busybox cp '" + uri + "' '" + file.getParent() + "/classes.dex'");
					command = "/data/data/per.pqy.apktool/apktool/7z.sh '" + file.getParent() + "' a -tzip '" + apkFile + "' '" + file.getParent() + "/classes.dex'";
					startWork(getString(R.string.adding), command, getString(R.string.add_finish));
				}
				else
				{
					showDialog("warning", "apk_not_exists", "");
				}
				break;
		}
	}

	public void onRefresh()
	{
		positionIndex = ((LinearLayoutManager)layoutManager).findFirstVisibleItemPosition();
		recyclerView.scrollToPosition(positionIndex);
		getDataPath(filePath.getPath());
	}

	public void onBack()
	{
		if (filePath.getPath().equals("/"))
		{
			getDataPath(STORAGE_PATH);
		}
		else
		{
			recyclerView.scrollToPosition(positionIndex);
			getDataPath(filePath.getParent());
		}
	}

	protected void onPermissionClick()
	{
		shell = sharedPreferences.getBoolean("root", false) ? "su" : "sh";
		RunExec.Cmd(shell, " chmod 777 " + file.getPath());
		onRefresh();
	}

	protected void onDeleteClick()
	{
		final String command = "rm -r '" + file.getPath() + "'";
		startWork(getString(R.string.deleting), command, getString(R.string.delete_finish));
	}

	protected void onRenameClick(String str)
	{
		shell = sharedPreferences.getBoolean("root", false) ? "su" : "sh";
		RunExec.Cmd(shell, " chmod 777 " + file.getPath());
		if (!str.isEmpty() && file.renameTo(new File(file.getParent() + "/" + str)))
		{
			onRefresh();
			Snackbar.make(getView(), "Renamed into: \"" + str + "\"", Snackbar.LENGTH_LONG).show();
		}
		else
		{
			Toast.makeText(context, "Con not rename " + file.getName(), Toast.LENGTH_SHORT).show();
		}

	}

	protected void onCardPathClick()
	{
		SharedPreferences.Editor editor = sharedPreferences.edit();
		if (editor.putString("micro_sd_path", file.getAbsolutePath()).commit())
		{
			Snackbar.make(getView(), file.getAbsolutePath(), Snackbar.LENGTH_LONG).show();
		}
	}

	/*private String getGooglePlayStoreUrl(){
	 String id = context.getApplicationInfo().packageName; // current google play is   using package name as id

	 PackageManager packageManager = context.getApplicationContext().getPackageManager();
	 Uri marketUri = Uri.parse("market://details?id=" + id);
	 Intent marketIntent = new Intent(Intent.ACTION_VIEW).setData(marketUri);
	 if (marketIntent.resolveActivity(packageManager) != null)
	 return "market://details?id=" + id;
	 else
	 return "https://play.google.com/store/apps/details?id=" + id;
	 }*/

	private void showDialog(String key, String value, String name)
	{
		AlertDialogFragment alertDialogFragment = new AlertDialogFragment().newInstance(key, value, name);
		alertDialogFragment.setTargetFragment(this, 0);
		alertDialogFragment.show(getFragmentManager(), "dialogFragment");
	}

	@Override
	public void onDestroy()
	{
		currentPath = filePath.getPath();
		SharedPreferences.Editor edit = sharedPreferences.edit();
		edit.putString("current_path", currentPath.equals(STORAGE_PATH) ? null : currentPath).commit();
		super.onDestroy();
	}
}
