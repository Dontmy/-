package per.pqy.apktool;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.support.v7.preference.PreferenceScreen;
import android.support.v7.preference.PreferenceManager;
import android.view.MenuItem;

public class SettingsActivity extends AppCompatActivity implements PreferenceFragmentCompat.OnPreferenceStartScreenCallback
{
	PreferenceScreen preferenceScreen;

	@Override
	public boolean onPreferenceStartScreen(PreferenceFragmentCompat p1, PreferenceScreen p2)
	{
		preferenceScreen = p2;
		p1.setPreferenceScreen(p2);
		//p1.setRetainInstance(true);
		// TODO: Implement this method
		return true;
	}


	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		getDelegate().setLocalNightMode(MainActivity.nightModeInt(PreferenceManager.getDefaultSharedPreferences(this).getString("theme", "day")));
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		if (savedInstanceState == null)
		{
			getSupportFragmentManager().beginTransaction().replace(android.R.id.content, new SettingsCompatFragment()).commit();
		}
	}

	@Override
	public void onBackPressed()
	{
		if (preferenceScreen != null)
		{
			getSupportFragmentManager().beginTransaction().replace(android.R.id.content, new SettingsCompatFragment()).commit();
			preferenceScreen = null;
		}
		else
		{
			super.onBackPressed();
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		onBackPressed();
		return true;
	}

}
