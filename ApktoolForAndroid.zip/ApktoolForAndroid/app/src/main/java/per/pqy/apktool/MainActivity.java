package per.pqy.apktool;

import android.support.v7.app.AppCompatActivity;
import android.support.design.widget.NavigationView;
import android.view.MenuItem;
import android.content.SharedPreferences;
import android.os.Environment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.support.v7.app.ActionBarDrawerToggle;
import java.io.File;
import android.content.Intent;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.AppCompatDelegate;
import android.os.Bundle;
import android.support.v7.preference.PreferenceManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AlertDialog;
import android.content.res.Configuration;
import android.view.Menu;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.WindowManager;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener
{
	MainFragment mainFragment;
	private SharedPreferences sharedPreferences;
	private static final String EXTERNAL_STORAGE = Environment.getExternalStorageDirectory().getPath();
	DrawerLayout drawerLayout;
	Toolbar toolbar;
	ActionBarDrawerToggle toggle;
	private static long back_pressed = 0;

	@Override
	public boolean onNavigationItemSelected(MenuItem p1)
	{
		mainFragment = (MainFragment) getSupportFragmentManager().findFragmentById(R.id.container);
		String microSD = sharedPreferences.getString("micro_sd_path", "");
		String systemFolder = Environment.getRootDirectory().getPath();

		switch (p1.getItemId())
		{
			case R.id.root_device:
				mainFragment.getDataPath("/");
				break;
			case R.id.system_folder:
				mainFragment.getDataPath(systemFolder);
				break;
			case R.id.internal_storage:
				mainFragment.getDataPath(EXTERNAL_STORAGE);
				break;
			case R.id.micro_sd_path:
				if (new File(microSD).canRead())
					mainFragment.getDataPath(microSD);
				else
					showDialog("warning", "microsd_not_exists");
				break;
			case R.id.settings:
				startActivity(new Intent(this, SettingsActivity.class));
				break;
			case R.id.information:
				startActivity(new Intent(this, InfoActivity.class));
				break;
			case R.id.logout:
				super.onBackPressed();
				break;
		}
		// TODO: Implement this method
		drawerLayout.closeDrawer(GravityCompat.START);
		return true;
	}

	public static int nightModeInt(String themeKey)
	{
		switch (themeKey)
		{
			case "auto":
				return AppCompatDelegate.MODE_NIGHT_AUTO;
			case "night":
				return AppCompatDelegate.MODE_NIGHT_YES;
			case "day":
			default:
				return AppCompatDelegate.MODE_NIGHT_NO;
		}
	}

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);	
        setContentView(R.layout.activity_main);

		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

		if (savedInstanceState == null)
		{
			if (!new File("/data/data/per.pqy.apktool/busybox").exists())
			{
				String shell = sharedPreferences.getBoolean("root", false) ? "su" : "sh";
				RunExec.Cmd(shell, "ln -s '/data/data/per.pqy.apktool/lib/libb.so' '/data/data/per.pqy.apktool/busybox'");
			}
		}

		String theme = sharedPreferences.getString("theme", "day");
		getDelegate().setLocalNightMode(nightModeInt(theme));

		toolbar = (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		getSupportActionBar().setDisplayShowTitleEnabled(false);

		drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_content_drawer, R.string.close_content_drawer);
		drawerLayout.addDrawerListener(toggle);

		//String currentPath = sharedPreferences.getString("current_path", null);
		//getSupportFragmentManager().beginTransaction().replace(R.id.container, new MainFragment().
		//													   newInstance((currentPath != null && new File(currentPath).canRead()) ? currentPath : externalStorage)).commit();
		getSupportFragmentManager().beginTransaction().replace(R.id.container, new MainFragment()).commit();
		//toggle.syncState();
		NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);
		navigationView.setNavigationItemSelectedListener(this);

		View headerView = navigationView.getHeaderView(0);
		ImageView imageView = (ImageView) headerView.findViewById(R.id.logo_image);
		TextView textView = (TextView) headerView.findViewById(R.id.app_version);

		Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_profile);
		RoundedBitmapDrawable rounded = RoundedBitmapDrawableFactory.create(getResources(), bitmap);
		rounded.setCircular(true);
		imageView.setImageDrawable(rounded);
		imageView.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					new AlertDialog.Builder(MainActivity.this).
						setTitle(R.string.menu_information).
						setMessage(aboutDevice()).
						setPositiveButton(R.string.close, null).
						show();
					// TODO: Implement this method
					drawerLayout.closeDrawer(GravityCompat.START);
				}
			});	  

		textView.append(" " + appVersionName());
    }


	@Override
	protected void onPostCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onPostCreate(savedInstanceState);
		toggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig)
	{
		// TODO: Implement this method
		super.onConfigurationChanged(newConfig);
		toggle.onConfigurationChanged(newConfig);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.toolbar_menu, menu);
		// TODO: Implement this method
		return true;
	}

	private void showDialog(String key, String value)
	{
		AlertDialogFragment dialogFragment = new AlertDialogFragment().newInstance(key, value, "");
		dialogFragment.show(getSupportFragmentManager(), "dialogFragment");
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		if (toggle.onOptionsItemSelected(item))
		{
			return true;
		}
		switch (item.getItemId())
		{
			case R.id.frame :
				showDialog("warning", "clean");
				break;
			case R.id.refresh :
				mainFragment = (MainFragment) getSupportFragmentManager().findFragmentById(R.id.container);
				mainFragment.onRefresh();
				break;
		}

		return super.onOptionsItemSelected(item);
	}

	private String appVersionName()
	{
		try
		{
			return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
		}
		catch (PackageManager.NameNotFoundException e)
		{}
		return null;
	}

	private String aboutDevice()
	{
		if (Build.VERSION.SDK_INT < 21)
		{
			return String.format(getResources().getString(R.string.info_about), Build.VERSION.RELEASE, Build.CPU_ABI, Build.CPU_ABI2, Build.VERSION.SDK);
		}
		else
		{
			String[] cpuAbi = Build.SUPPORTED_ABIS;
			return String.format(getResources().getString(R.string.info_about), Build.VERSION.RELEASE, cpuAbi[0], cpuAbi[1], Build.VERSION.SDK);
		}
	}

	protected void onKeepScreen()
	{
		int f = getWindow().getAttributes().flags;
		boolean ks = sharedPreferences.getBoolean("keep_screen", false);
		if (ks == true && (f & 128) != 128) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		if (ks == false && (f & 128) == 128) getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	}

	@Override
	protected void onStart()
	{
		onKeepScreen();
		// TODO: Implement this method
		super.onStart();
	}

	@Override
	public void onBackPressed()
	{
		mainFragment = (MainFragment) getSupportFragmentManager().findFragmentById(R.id.container);
		if (drawerLayout.isDrawerOpen(GravityCompat.START))
		{
			drawerLayout.closeDrawer(GravityCompat.START);
		}
		else if (!mainFragment.filePath.getPath().equals(EXTERNAL_STORAGE))
		{
			mainFragment.onBack();
		}
		else
		{
			if (back_pressed + 2000 > System.currentTimeMillis())
			{
				super.onBackPressed();
			}
			else
			{
				Toast.makeText(getApplicationContext(), R.string.on_back_pressed, Toast.LENGTH_SHORT).show();
				back_pressed = System.currentTimeMillis();
			}
		}
	}
}
