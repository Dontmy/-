package per.pqy.apktool;

import android.support.v7.preference.PreferenceFragmentCompat;
import android.support.v7.preference.Preference;
import android.support.v7.preference.ListPreference;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

public class SettingsCompatFragment extends PreferenceFragmentCompat implements Preference.OnPreferenceChangeListener, Preference.OnPreferenceClickListener
{
	static String aaptPath = "/data/data/per.pqy.apktool/apktool/openjdk/bin";
	static String apktoolPath = "/data/data/per.pqy.apktool/apktool";
	static String apktool2entries;

	@Override
	public boolean onPreferenceClick(Preference p1)
	{
		switch (p1.getKey())
		{
			case "file_update":
				SelectDialogFragment selectDialogFragment = new SelectDialogFragment();
				selectDialogFragment.setTargetFragment(this, 0);
				selectDialogFragment.show(getFragmentManager(), "selectDialogFragment");
				break;
			case "clean":
				AlertDialogFragment alertDialogFragment = new AlertDialogFragment().newInstance("warning", "clean", "");
				alertDialogFragment.setTargetFragment(this, 0);
				alertDialogFragment.show(getFragmentManager(), "dialogFragment");
				break;
		}
		// TODO: Implement this method
		return false;
	}


	@Override
	public boolean onPreferenceChange(Preference p1, Object p2)
	{
		if (p1 instanceof ListPreference)
		{
			ListPreference listPreference = (ListPreference) p1;
			String prefix = "";
			switch (p1.getKey())
			{
				case "aapt_version":
					prefix = "aapt ";
					break;
				case "apktool_version":
					prefix = "apktool ";
					break;
				case "theme":
					Intent intent = getActivity().getIntent();
					getActivity().finish();
					startActivity(intent);
					return true;
			}

			int index = listPreference.findIndexOfValue(p2.toString());
			p1.setSummary(index >= 0 ? (prefix + listPreference.getEntries()[index]) : null);
			return true;
		}
		else
			return false;
	}


	@Override
	public void onCreatePreferences(Bundle p1, String p2)
	{
		//setRetainInstance(true);
		if (Build.VERSION.SDK_INT < 11)
		{
			addPreferencesFromResource(R.xml.preferences);
		}
		else
		{
			addPreferencesFromResource(R.xml.preferences_multi);
		}
		apktool2entries = getResources().getStringArray(R.array.apktool_version_entries)[1];

		findPreference("clean").setOnPreferenceClickListener(this);
		findPreference("file_update").setOnPreferenceClickListener(this);

		onListPreference("theme");
		onListPreference("apktool_version");
		onListPreference("aapt_version");
	}

	public void onListPreference(String keyPref)
	{
		String prefixStart = "";
		String prefixEnd = "";
		String[] entries;
		ListPreference listPreference = (ListPreference) findPreference(keyPref);
		listPreference.setOnPreferenceChangeListener(this);
		switch (keyPref)
		{
			case "aapt_version":
				prefixStart = "aapt ";
				entries = aaptEntries();
				if (entries != null)
				{
					listPreference.setEntries(entries);
					listPreference.setEntryValues(entries);
				}
				else
				{
					listPreference.setSelectable(false);
				}
				break;
			case "apktool_version":
				entries = apktoolEntries();
				if (entries != null)
				{
					listPreference.setEntries(entries);
				}
				prefixStart = "apktool ";
				break;
			case "theme":
				prefixEnd = ". " + getResources().getStringArray(R.array.theme_prefix)[listPreference.findIndexOfValue(listPreference.getValue())];
				break;
		}
		listPreference.setSummary(prefixStart + listPreference.getEntry() + prefixEnd);
	}

	private static String[] aaptEntries()
	{
		File path = new File(aaptPath);
		if (!path.canRead()) return null;
		File[] files = path.listFiles(new FileFilter(){

				@Override
				public boolean accept(File p1)
				{
					return p1.isFile() && p1.getName().startsWith("aapt");
				}
			});
		Arrays.sort(files);
		List<String> arr = new ArrayList<String>();
		for (File f : files)
		{
			arr.add(f.getName().replaceFirst("aapt", ""));
		}
		return arr.toArray(new String[]{});
	}

	private static String[] apktoolEntries()
	{
		File path = new File(apktoolPath);
		if (!path.canRead()) return null;
		File[] files = path.listFiles(new FileFilter(){

				@Override
				public boolean accept(File p1)
				{
					// TODO: Implement this method
					return p1.isFile() && p1.getName().matches("(apktool)(_|-)[0-9.a-z]*.jar");
				}
			});
		if (files.length < 1) return null;
		Arrays.sort(files, new Comparator<File>(){

				@Override
				public int compare(File p1, File p2)
				{
					// TODO: Implement this method
					return Long.valueOf(p1.lastModified()).compareTo(p2.lastModified());
				}
			});
		String fileName = files[files.length - 1].getName();
		return new String[]{fileName.substring(8, fileName.lastIndexOf(".")), apktool2entries};
	}

}
