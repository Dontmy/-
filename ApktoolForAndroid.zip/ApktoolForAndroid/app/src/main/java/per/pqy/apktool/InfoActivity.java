package per.pqy.apktool;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import java.io.File;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import java.io.FileFilter;
import java.util.Arrays;
import android.view.MenuItem;

public class InfoActivity extends AppCompatActivity
{
	private RecyclerView recyclerView;
	private RecyclerView.LayoutManager layoutManager;
	private File[] files;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.recycler_info_view);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		recyclerView = (RecyclerView) findViewById(R.id.info_recycler_view);
		recyclerView.setHasFixedSize(true);
		layoutManager = new LinearLayoutManager(this);
		recyclerView.setLayoutManager(layoutManager);
		recyclerView.setAdapter(new InfoAdapter(concatFile()));
	}

	private File[] concatFile()
	{
		File[] a = onListFiles("aapt");
		File[] b = onListFiles("jar");
		if (a == null) return b;
		if (b == null) return a;
		File[] r = new File[a.length + b.length];
		System.arraycopy(a, 0, r, 0, a.length);
		System.arraycopy(b, 0, r, a.length, b.length);
		return r;
	}

	private File[] onListFiles(String str)
	{
		String notFiles = "files not found";
		String path = "/data/data/per.pqy.apktool/apktool";
		if (str.equals("aapt"))
		{
			notFiles = "aapt not found";
			path += "/openjdk/bin";
		}
		File dir = new File(path);
		if (dir.canRead())
		{
			files = dir.listFiles(new FileFilter(){

					@Override
					public boolean accept(File p1)
					{
						String name = p1.getName();
						// TODO: Implement this method
						return name.startsWith("aapt") || name.matches("(apktool|smali|baksmali|oat2dex)[\\_\\-0-9.a-z]*.jar");
					}
				});
			Arrays.sort(files);
		}
		else
		{
			files = new File[]{new File(notFiles)};
		}
		return files;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		onBackPressed();
		return true;
	}
}
