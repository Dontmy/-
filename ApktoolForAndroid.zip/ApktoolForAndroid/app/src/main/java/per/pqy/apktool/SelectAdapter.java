package per.pqy.apktool;

import android.support.v7.widget.RecyclerView;
import java.io.File;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;

public class SelectAdapter extends RecyclerView.Adapter<SelectAdapter.ViewHolder>
{
	public static ClickListener clickLictener;
	private File[] dataset;
	private File f;

	interface ClickListener
	{
		void onItemClick(int positoin);
	}

	public SelectAdapter(File[] d, ClickListener l)
	{
		dataset = d;
		this.clickLictener = l;
	}
	static class ViewHolder extends RecyclerView.ViewHolder
	{
		private TextView nameTextView;
		private ImageView iconImageView;
		public ViewHolder(View v)
		{
			super(v);
			nameTextView = (TextView) v.findViewById(R.id.name_text_view);
			iconImageView = (ImageView) v.findViewById(R.id.icon_image_view);

			v.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1)
					{
						clickLictener.onItemClick(getPosition());
						// TODO: Implement this method
					}
				});
		}
	}
	@Override
	public SelectAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
	{
		View view = LayoutInflater.from(p1.getContext()).inflate(R.layout.recycler_select_item, p1, false);

		// TODO: Implement this method
		return new ViewHolder(view);
	}

	@Override
	public void onBindViewHolder(ViewHolder p1, int p2)
	{
		f = dataset[p2];
		p1.nameTextView.setText(f.getName());
		p1.iconImageView.setImageResource(f.isFile() ? (f.getName().startsWith("aapt") ? R.drawable.ic_matrix_24dp : R.drawable.ic_zip_box_24dp) : (f.canRead() ? R.drawable.ic_folder_24dp : R.drawable.ic_folder_lock_24dp));
		if (f.isFile())
		{
			p1.iconImageView.setBackgroundResource(R.drawable.file_background);
		}
		else
		{
			p1.iconImageView.setBackgroundResource(R.drawable.folder_background);
		}
		// TODO: Implement this method
	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return dataset.length;
	}

}
